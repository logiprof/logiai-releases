// Mise à jour de Logi AI web depuis le dépôt public des publications (GitHub).
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

const DEPOT = process.env.LOGIAI_DEPOT || "https://raw.githubusercontent.com/logiprof/logiai-releases/main/web";
const AUTORISES = ["public/", "serveur/", "package.json", "LISEZMOI.txt"];

let cache = null; // { date, info }
export async function derniereVersion(forcer = false) {
  if (!forcer && cache && Date.now() - cache.date < 3600000) return cache.info;
  const r = await fetch(`${DEPOT}/latest.json?t=${Date.now()}`, { headers: { "User-Agent": "LogiAI" } });
  if (!r.ok) throw new Error(`Vérification impossible (code ${r.status}).`);
  const info = await r.json();
  cache = { date: Date.now(), info };
  return info;
}

export const plusRecente = (a, b) => {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
};

/** Lit une archive .tar (format ustar / GNU) : [{ nom, type, donnees }]. */
function lireTar(buf) {
  const sortie = [];
  let i = 0;
  let nomLong = null;
  const texte = (d, f) => buf.subarray(d, f).toString("utf8").replace(/\0.*$/s, "");
  while (i + 512 <= buf.length) {
    if (buf.subarray(i, i + 512).every((o) => o === 0)) break;
    let nom = texte(i, i + 100);
    const taille = parseInt(texte(i + 124, i + 136).trim() || "0", 8);
    const type = String.fromCharCode(buf[i + 156] || 48);
    const prefixe = texte(i + 345, i + 500);
    if (prefixe) nom = `${prefixe}/${nom}`;
    const donnees = buf.subarray(i + 512, i + 512 + taille);
    i += 512 + Math.ceil(taille / 512) * 512;
    if (type === "L") {
      nomLong = donnees.toString("utf8").replace(/\0.*$/s, "");
      continue;
    }
    if (type === "x" || type === "g") continue;
    if (nomLong) {
      nom = nomLong;
      nomLong = null;
    }
    sortie.push({ nom: nom.replace(/^\.\//, ""), type, donnees });
  }
  return sortie;
}

/** Télécharge, vérifie et installe la dernière version. Les données (donnees/) ne sont jamais touchées. */
export async function installer(RACINE, DONNEES) {
  const info = await derniereVersion(true);
  const r = await fetch(`${DEPOT}/logiai-web-${info.version}.tar.gz`, { headers: { "User-Agent": "LogiAI" } });
  if (!r.ok) throw new Error(`Téléchargement impossible (code ${r.status}).`);
  const gz = Buffer.from(await r.arrayBuffer());
  if (info.sha256 && crypto.createHash("sha256").update(gz).digest("hex") !== info.sha256) throw new Error("Le paquet téléchargé est altéré (empreinte incorrecte) : mise à jour annulée.");
  const entrees = lireTar(zlib.gunzipSync(gz));
  if (!entrees.some((e) => e.nom === "serveur/serveur.mjs") || !entrees.some((e) => e.nom === "public/index.html")) throw new Error("Paquet incomplet : mise à jour annulée.");

  const tmp = path.join(DONNEES, "maj-en-cours");
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  for (const e of entrees) {
    if (!AUTORISES.some((a) => e.nom === a || (a.endsWith("/") && e.nom.startsWith(a)))) continue;
    const p = path.resolve(tmp, e.nom);
    if (!p.startsWith(tmp + path.sep)) continue;
    if (e.type === "5") fs.mkdirSync(p, { recursive: true });
    else if (e.type === "0" || e.type === "\0") {
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, e.donnees);
    }
  }
  // Échange des dossiers (l'ancienne version est gardée jusqu'au bout en cas de problème).
  for (const d of ["public", "serveur"]) {
    const ancien = path.join(RACINE, `${d}.ancien`);
    fs.rmSync(ancien, { recursive: true, force: true });
    if (fs.existsSync(path.join(RACINE, d))) fs.renameSync(path.join(RACINE, d), ancien);
    fs.renameSync(path.join(tmp, d), path.join(RACINE, d));
  }
  for (const f of ["package.json", "LISEZMOI.txt"]) if (fs.existsSync(path.join(tmp, f))) fs.copyFileSync(path.join(tmp, f), path.join(RACINE, f));
  for (const d of ["public", "serveur"]) fs.rmSync(path.join(RACINE, `${d}.ancien`), { recursive: true, force: true });
  fs.rmSync(tmp, { recursive: true, force: true });
  return info.version;
}
