// Logi AI web — serveur Node.js (Infomaniak). Aucune dépendance externe.
// Démarrage : npm start (node serveur.mjs). Port : variable PORT (3000 par défaut).
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { creerSecurite } from "./securite.mjs";
import { creerCommandes } from "./commandes.mjs";
import { derniereVersion, installer, plusRecente } from "./miseajour.mjs";

const ICI = path.dirname(fileURLToPath(import.meta.url));
const RACINE = path.resolve(ICI, "..");
const PUBLIC = path.join(RACINE, "public");
const DONNEES = process.env.LOGIAI_DONNEES || path.join(RACINE, "donnees");
const PORT = Number(process.env.PORT) || 3000;
const VERSION = JSON.parse(fs.readFileSync(path.join(RACINE, "package.json"), "utf8")).version;

fs.mkdirSync(DONNEES, { recursive: true, mode: 0o700 });
fs.mkdirSync(path.join(DONNEES, "sauvegardes"), { recursive: true });

const securite = creerSecurite(DONNEES);
const { commandes, reel } = creerCommandes({ securite, DONNEES });

// ---------- Données synchronisées ----------
const FICHIER_DONNEES = path.join(DONNEES, "donnees.json");
let copie = (() => {
  try {
    return JSON.parse(fs.readFileSync(FICHIER_DONNEES, "utf8"));
  } catch {
    return { version: 0, donnees: null };
  }
})();
function enregistrerCopie(donnees) {
  copie = { version: copie.version + 1, donnees, modifieLe: new Date().toISOString() };
  const tmp = FICHIER_DONNEES + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(copie), { mode: 0o600 });
  fs.renameSync(tmp, FICHIER_DONNEES);
  // Sauvegarde quotidienne (30 jours gardés).
  const jour = new Date().toISOString().slice(0, 10);
  const s = path.join(DONNEES, "sauvegardes", `donnees-${jour}.json`);
  if (!fs.existsSync(s)) {
    fs.writeFileSync(s, JSON.stringify(copie), { mode: 0o600 });
    const l = fs.readdirSync(path.dirname(s)).filter((x) => x.startsWith("donnees-")).sort();
    while (l.length > 30) fs.rmSync(path.join(path.dirname(s), l.shift()));
  }
  return copie.version;
}

// ---------- Outils HTTP ----------
const ENTETES = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Strict-Transport-Security": "max-age=31536000",
  "Permissions-Policy": "camera=(), microphone=(self), geolocation=()",
  "Cross-Origin-Opener-Policy": "same-origin",
};
const CSP = "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; img-src 'self' data: blob:; media-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; font-src 'self' data:; connect-src 'self'; worker-src 'self' blob:; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'";

function repondre(res, code, corps, entetes = {}) {
  const json = typeof corps !== "string" && !Buffer.isBuffer(corps);
  res.writeHead(code, { ...ENTETES, "Cache-Control": "no-store", ...(json ? { "Content-Type": "application/json; charset=utf-8" } : {}), ...entetes });
  res.end(json ? JSON.stringify(corps) : corps);
}
const erreur = (res, code, message) => repondre(res, code, { erreur: message });

function lireCorps(req, max) {
  return new Promise((ok, ko) => {
    const morceaux = [];
    let taille = 0;
    req.on("data", (c) => {
      taille += c.length;
      if (taille > max) {
        ko(Object.assign(new Error("Envoi trop volumineux."), { code: 413 }));
        req.destroy();
      } else morceaux.push(c);
    });
    req.on("end", () => ok(Buffer.concat(morceaux)));
    req.on("error", ko);
  });
}
async function lireJSON(req, max = 80 * 1024 * 1024) {
  const b = await lireCorps(req, max);
  if (!b.length) return {};
  try {
    return JSON.parse(b.toString("utf8"));
  } catch {
    throw Object.assign(new Error("Requête illisible."), { code: 400 });
  }
}

const cookies = (req) => Object.fromEntries((req.headers.cookie || "").split(";").map((c) => c.trim().split("=")).filter((x) => x.length === 2));
const ip = (req) => String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || "?";
const COOKIE = "logiai_session";
const cookieSession = (jeton) => `${COOKIE}=${jeton}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${12 * 3600}`;

const MIMES = { webmanifest: "application/manifest+json", html: "text/html; charset=utf-8", js: "text/javascript; charset=utf-8", mjs: "text/javascript; charset=utf-8", css: "text/css; charset=utf-8", svg: "image/svg+xml", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif", ico: "image/x-icon", woff: "font/woff", woff2: "font/woff2", json: "application/json", wasm: "application/wasm", txt: "text/plain; charset=utf-8", md: "text/markdown; charset=utf-8", csv: "text/csv; charset=utf-8", pdf: "application/pdf", mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", m4v: "video/mp4", mp3: "audio/mpeg", wav: "audio/wav", m4a: "audio/mp4", zip: "application/zip", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation", avif: "image/avif", heic: "image/heic", htm: "text/html; charset=utf-8", lottie: "application/zip" };

function servirStatique(req, res, chemin) {
  let p = path.resolve(PUBLIC, "." + decodeURIComponent(chemin));
  if (!p.startsWith(PUBLIC + path.sep) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) p = path.join(PUBLIC, "index.html");
  const ext = path.extname(p).slice(1).toLowerCase();
  const immuable = chemin.startsWith("/assets/");
  res.writeHead(200, { ...ENTETES, "Content-Type": MIMES[ext] || "application/octet-stream", "Cache-Control": immuable ? "public, max-age=31536000, immutable" : "no-cache", ...(ext === "html" ? { "Content-Security-Policy": CSP } : {}) });
  fs.createReadStream(p).pipe(res);
}

// ---------- Routes ----------
async function traiter(req, res) {
  const url = new URL(req.url, "http://localhost");
  const chemin = url.pathname;
  const m = req.method;

  if (!chemin.startsWith("/api/")) {
    if (m !== "GET" && m !== "HEAD") return erreur(res, 405, "Méthode non autorisée.");
    return servirStatique(req, res, chemin);
  }

  // Synchronisation de l'application Mac (jeton « lgs_… »).
  if (chemin.startsWith("/api/sync/")) {
    const jeton = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
    if (!securite.jetonValide(jeton)) return erreur(res, 401, "Jeton de synchronisation refusé : reliez à nouveau le Mac (Réglages › Logi AI web).");
    if (chemin === "/api/sync/etat" && m === "GET") return repondre(res, 200, { ok: true, version: copie.version, serveur: VERSION });
    if (chemin === "/api/sync/donnees") return routeDonnees(req, res, m);
    if (chemin === "/api/sync/cles" && m === "POST") {
      const { cles } = await lireJSON(req, 2 * 1024 * 1024);
      if (!cles || typeof cles !== "object") return erreur(res, 400, "Clés manquantes.");
      const actuelles = securite.cles();
      for (const [k, v] of Object.entries(cles)) if (typeof v === "string" && k !== "synchro") actuelles[k] = v;
      securite.enregistrerCles(actuelles);
      return repondre(res, 200, { ok: true, nombre: Object.keys(cles).length });
    }
    return erreur(res, 404, "Introuvable.");
  }

  // Protection contre les requêtes venues d'autres sites : en-tête obligatoire.
  if (m !== "GET" && req.headers["x-logiai"] !== "1") return erreur(res, 403, "Requête refusée.");

  const jeton = cookies(req)[COOKIE];
  if (chemin === "/api/session" && m === "GET") {
    if (!securite.estInstalle()) {
      securite.codeInstallation();
      return repondre(res, 200, { etat: "installation", version: VERSION });
    }
    return repondre(res, 200, { etat: securite.session(jeton) ? "ok" : "connexion", version: VERSION });
  }
  if (chemin === "/api/installation/debut" && m === "POST") {
    const { code } = await lireJSON(req, 10000);
    try {
      return repondre(res, 200, securite.debutInstallation(code));
    } catch (e) {
      return erreur(res, 400, e.message);
    }
  }
  if (chemin === "/api/installation/fin" && m === "POST") {
    const { code, motDePasse, codeTotp } = await lireJSON(req, 10000);
    try {
      securite.finInstallation(code, motDePasse, codeTotp);
      return repondre(res, 200, { ok: true }, { "Set-Cookie": cookieSession(securite.nouvelleSession()) });
    } catch (e) {
      return erreur(res, 400, e.message);
    }
  }
  if (chemin === "/api/connexion" && m === "POST") {
    const { motDePasse, code } = await lireJSON(req, 10000);
    try {
      const s = securite.connexion(ip(req), motDePasse, code);
      return repondre(res, 200, { ok: true }, { "Set-Cookie": cookieSession(s) });
    } catch (e) {
      return erreur(res, 401, e.message);
    }
  }
  if (chemin === "/api/deconnexion" && m === "POST") {
    securite.deconnexion(jeton);
    return repondre(res, 200, { ok: true }, { "Set-Cookie": `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0` });
  }

  // ----- Tout le reste demande une session -----
  if (!securite.session(jeton)) return erreur(res, 401, "Session expirée : reconnectez-vous.");

  if (chemin === "/api/donnees") return routeDonnees(req, res, m);

  if (chemin.startsWith("/api/invoke/") && m === "POST") {
    const nom = chemin.slice("/api/invoke/".length);
    const f = Object.hasOwn(commandes, nom) ? commandes[nom] : null;
    if (!f) return erreur(res, 404, `Commande inconnue : ${nom}`);
    const args = await lireJSON(req);
    try {
      const r = await f(args);
      return repondre(res, 200, { resultat: r ?? null });
    } catch (e) {
      const message = typeof e === "string" ? e : (e?.message ?? "Erreur inattendue.");
      if (typeof e !== "string") console.error(`[${nom}]`, e);
      return erreur(res, 400, message);
    }
  }

  if (chemin === "/api/fichier" && m === "GET") {
    let p;
    try {
      p = reel(url.searchParams.get("chemin"));
    } catch (e) {
      return erreur(res, 403, String(e));
    }
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) return erreur(res, 404, "Fichier introuvable.");
    const ext = path.extname(p).slice(1).toLowerCase();
    const telecharger = url.searchParams.get("telecharger") === "1";
    res.writeHead(200, {
      ...ENTETES,
      "Content-Type": MIMES[ext] || "application/octet-stream",
      "Cache-Control": "private, max-age=300",
      "Content-Length": fs.statSync(p).size,
      // Les pages HTML (jeux) s'ouvrent isolées du reste de Logi AI.
      "Content-Security-Policy": "sandbox allow-scripts allow-popups allow-forms; frame-ancestors 'self'",
      "X-Frame-Options": "SAMEORIGIN",
      "Content-Disposition": `${telecharger ? "attachment" : "inline"}; filename*=UTF-8''${encodeURIComponent(path.basename(p))}`,
    });
    return fs.createReadStream(p).pipe(res);
  }

  if (chemin === "/api/televerser" && m === "POST") {
    const nom = path.basename(decodeURIComponent(String(req.headers["x-nom"] || "fichier"))).replace(/[\\/:*?"<>|]+/g, "-").slice(0, 120) || "fichier";
    const b = await lireCorps(req, 300 * 1024 * 1024);
    const dossier = `/Logi AI/Téléversements/${new Date().toISOString().slice(0, 10)}`;
    const p = reel(`${dossier}/${nom}`);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, b);
    return repondre(res, 200, { chemin: `${dossier}/${nom}` });
  }

  if (chemin === "/api/jetons-synchro") {
    if (m === "GET") return repondre(res, 200, securite.listerJetons());
    if (m === "POST") {
      const { nom } = await lireJSON(req, 10000);
      return repondre(res, 200, { jeton: securite.creerJeton(nom) });
    }
  }
  if (chemin === "/api/jetons-synchro/retirer" && m === "POST") {
    const { id } = await lireJSON(req, 10000);
    securite.retirerJeton(id);
    return repondre(res, 200, { ok: true });
  }
  if (chemin === "/api/mise-a-jour" && m === "GET") {
    try {
      const d = await derniereVersion(url.searchParams.get("forcer") === "1");
      return repondre(res, 200, { actuelle: VERSION, derniere: d.version, date: d.date, disponible: plusRecente(d.version, VERSION) });
    } catch (e) {
      return erreur(res, 502, e.message);
    }
  }
  if (chemin === "/api/mise-a-jour" && m === "POST") {
    try {
      const v = await installer(RACINE, DONNEES);
      const auto = process.env.LOGIAI_LANCEUR === "1";
      repondre(res, 200, { version: v, redemarrage: auto });
      // Avec le lanceur, le serveur redémarre tout seul sur la nouvelle version.
      if (auto) setTimeout(() => process.exit(99), 400);
      return;
    } catch (e) {
      return erreur(res, 500, e.message);
    }
  }
  if (chemin === "/api/deconnecter-tout" && m === "POST") {
    securite.deconnecterTout();
    return repondre(res, 200, { ok: true });
  }

  return erreur(res, 404, "Introuvable.");
}

async function routeDonnees(req, res, m) {
  if (m === "GET") return repondre(res, 200, { version: copie.version, donnees: copie.donnees });
  if (m === "PUT") {
    const { version, donnees } = await lireJSON(req);
    if (!donnees || donnees.version !== 1 || !Array.isArray(donnees.projets)) return erreur(res, 400, "Données invalides.");
    if (version !== copie.version) return repondre(res, 409, { erreur: "Modifiées entre-temps.", actuel: { version: copie.version, donnees: copie.donnees } });
    return repondre(res, 200, { version: enregistrerCopie(donnees) });
  }
  return erreur(res, 405, "Méthode non autorisée.");
}

const serveur = http.createServer((req, res) => {
  traiter(req, res).catch((e) => {
    if (!res.headersSent) erreur(res, e.code === 413 || e.code === 400 ? e.code : 500, e.message || "Erreur du serveur.");
    if (!e.code) console.error(e);
  });
});
serveur.requestTimeout = 15 * 60000; // générations longues
serveur.headersTimeout = 60000;
serveur.listen(PORT, () => {
  console.log(`Logi AI web ${VERSION} prêt sur le port ${PORT}.`);
  const code = securite.codeInstallation();
  if (code) console.log(`\n=== INSTALLATION ===\nCode d'installation : ${code}\nOuvrez votre adresse Logi AI web et saisissez ce code pour créer votre compte.\n====================\n`);
});
