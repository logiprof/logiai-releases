// Sécurité de Logi AI web : compte unique, mot de passe + code à 6 chiffres (2FA),
// sessions, jetons de synchronisation du Mac, coffre chiffré des clés.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export function creerSecurite(DONNEES) {
  const f = (n) => path.join(DONNEES, n);
  const lireJSON = (n, defaut) => {
    try {
      return JSON.parse(fs.readFileSync(f(n), "utf8"));
    } catch {
      return defaut;
    }
  };
  const ecrireJSON = (n, v) => {
    const tmp = f(n) + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(v), { mode: 0o600 });
    fs.renameSync(tmp, f(n));
  };

  // ---------- Clé maîtresse (chiffre les clés API et le secret 2FA) ----------
  let maitresse;
  if (fs.existsSync(f("secret.key"))) maitresse = Buffer.from(fs.readFileSync(f("secret.key"), "utf8").trim(), "hex");
  else {
    maitresse = crypto.randomBytes(32);
    fs.writeFileSync(f("secret.key"), maitresse.toString("hex"), { mode: 0o600 });
  }
  const chiffrer = (texte) => {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv("aes-256-gcm", maitresse, iv);
    const donnees = Buffer.concat([c.update(texte, "utf8"), c.final()]);
    return { iv: iv.toString("base64"), tag: c.getAuthTag().toString("base64"), donnees: donnees.toString("base64") };
  };
  const dechiffrer = (o) => {
    const d = crypto.createDecipheriv("aes-256-gcm", maitresse, Buffer.from(o.iv, "base64"));
    d.setAuthTag(Buffer.from(o.tag, "base64"));
    return Buffer.concat([d.update(Buffer.from(o.donnees, "base64")), d.final()]).toString("utf8");
  };

  // ---------- Coffre des clés (équivalent du Trousseau macOS) ----------
  let cacheCles = null;
  const cles = () => {
    if (cacheCles) return { ...cacheCles };
    const o = lireJSON("cles.json", null);
    cacheCles = o ? JSON.parse(dechiffrer(o)) : {};
    return { ...cacheCles };
  };
  const enregistrerCles = (map) => {
    ecrireJSON("cles.json", chiffrer(JSON.stringify(map)));
    cacheCles = { ...map };
  };

  // ---------- Mot de passe ----------
  const hacher = (mdp, sel = crypto.randomBytes(16).toString("hex")) => ({ sel, hash: crypto.scryptSync(mdp, sel, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }).toString("hex") });
  const verifierMdp = (mdp, c) => {
    const h = Buffer.from(hacher(mdp, c.sel).hash, "hex");
    const attendu = Buffer.from(c.hash, "hex");
    return h.length === attendu.length && crypto.timingSafeEqual(h, attendu);
  };

  // ---------- Codes à 6 chiffres (TOTP, compatible Google Authenticator, Authy, 1Password…) ----------
  const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const versB32 = (buf) => {
    let bits = "";
    for (const o of buf) bits += o.toString(2).padStart(8, "0");
    let s = "";
    for (let i = 0; i + 5 <= bits.length; i += 5) s += B32[parseInt(bits.slice(i, i + 5), 2)];
    return s;
  };
  const depuisB32 = (s) => {
    let bits = "";
    for (const c of s.replace(/=+$/, "").toUpperCase()) bits += B32.indexOf(c).toString(2).padStart(5, "0");
    const o = [];
    for (let i = 0; i + 8 <= bits.length; i += 8) o.push(parseInt(bits.slice(i, i + 8), 2));
    return Buffer.from(o);
  };
  const totp = (secret, pas) => {
    const b = Buffer.alloc(8);
    b.writeBigUInt64BE(BigInt(pas));
    const h = crypto.createHmac("sha1", depuisB32(secret)).update(b).digest();
    const o = h[h.length - 1] & 0xf;
    return String((h.readUInt32BE(o) & 0x7fffffff) % 1000000).padStart(6, "0");
  };
  /** Vérifie un code (±30 s) et refuse de réutiliser un code déjà accepté. */
  let dernierPas = 0;
  const verifierCode = (secret, code, memoriser = true) => {
    code = String(code || "").replace(/\D/g, "");
    if (code.length !== 6) return false;
    const pas = Math.floor(Date.now() / 30000);
    for (const d of [-1, 0, 1]) {
      const attendu = totp(secret, pas + d);
      if (crypto.timingSafeEqual(Buffer.from(attendu), Buffer.from(code))) {
        if (memoriser) {
          if (pas + d <= dernierPas) return false;
          dernierPas = pas + d;
        }
        return true;
      }
    }
    return false;
  };

  // ---------- Compte ----------
  const compte = () => lireJSON("compte.json", null);
  const estInstalle = () => !!compte();

  // Code d'installation : prouve que la personne qui crée le compte a accès au Manager Infomaniak.
  const codeInstallation = () => {
    if (estInstalle()) return null;
    let c = lireJSON("code-installation.json", null);
    if (!c) {
      c = { code: crypto.randomBytes(5).toString("hex").toUpperCase().replace(/(.{5})/, "$1-") };
      ecrireJSON("code-installation.json", c);
    }
    return c.code;
  };
  let enCours = null; // { secret, expire }
  const debutInstallation = (code) => {
    const attendu = codeInstallation();
    if (!attendu || String(code || "").trim().toUpperCase() !== attendu) throw new Error("Code d'installation incorrect. Il s'affiche dans la console du site (Manager Infomaniak › Node.js › Ouvrir la console).");
    enCours = { secret: versB32(crypto.randomBytes(20)), expire: Date.now() + 15 * 60000 };
    return { secret: enCours.secret, uri: `otpauth://totp/Logi%20AI:LogiProf?secret=${enCours.secret}&issuer=Logi%20AI&period=30&digits=6` };
  };
  const finInstallation = (code, motDePasse, codeTotp) => {
    const attendu = codeInstallation();
    if (!attendu || String(code || "").trim().toUpperCase() !== attendu) throw new Error("Code d'installation incorrect.");
    if (!enCours || enCours.expire < Date.now()) throw new Error("L'installation a expiré : recommencez.");
    if (typeof motDePasse !== "string" || motDePasse.length < 12) throw new Error("Le mot de passe doit compter au moins 12 caractères.");
    if (!verifierCode(enCours.secret, codeTotp)) throw new Error("Code à 6 chiffres incorrect : vérifiez l'heure du téléphone et recommencez.");
    ecrireJSON("compte.json", { motDePasse: hacher(motDePasse), totp: chiffrer(enCours.secret), creeLe: new Date().toISOString() });
    fs.rmSync(f("code-installation.json"), { force: true });
    enCours = null;
  };

  // ---------- Limitation des essais ----------
  const essais = new Map(); // ip → { n, jusqua }
  let echecsHeure = [];
  const bloque = (ip) => {
    const e = essais.get(ip);
    echecsHeure = echecsHeure.filter((t) => t > Date.now() - 3600000);
    if (echecsHeure.length >= 30) return "Trop d'essais ces dernières minutes : connexion bloquée pendant une heure.";
    if (e && e.jusqua > Date.now()) return `Trop d'essais : réessayez dans ${Math.ceil((e.jusqua - Date.now()) / 60000)} minute(s).`;
    return null;
  };
  const echec = (ip) => {
    const e = essais.get(ip) ?? { n: 0, jusqua: 0 };
    e.n += 1;
    if (e.n >= 5) {
      e.jusqua = Date.now() + 15 * 60000;
      e.n = 0;
    }
    essais.set(ip, e);
    echecsHeure.push(Date.now());
  };

  const connexion = (ip, motDePasse, code) => {
    const b = bloque(ip);
    if (b) throw new Error(b);
    const c = compte();
    if (!c) throw new Error("Logi AI web n'est pas encore installé.");
    const ok = typeof motDePasse === "string" && verifierMdp(motDePasse, c.motDePasse) && verifierCode(dechiffrer(c.totp), code);
    if (!ok) {
      echec(ip);
      throw new Error("Mot de passe ou code incorrect.");
    }
    essais.delete(ip);
    return nouvelleSession();
  };

  // ---------- Sessions (cookie) ----------
  const INACTIVITE = 4 * 3600000; // ordinateurs d'école : déconnexion après 4 h sans activité
  const DUREE_MAX = 12 * 3600000;
  const sha = (t) => crypto.createHash("sha256").update(t).digest("hex");
  let sessions = lireJSON("sessions.json", {});
  const sauverSessions = () => ecrireJSON("sessions.json", sessions);
  const nouvelleSession = () => {
    const jeton = crypto.randomBytes(32).toString("base64url");
    sessions[sha(jeton)] = { cree: Date.now(), vu: Date.now() };
    sauverSessions();
    return jeton;
  };
  let derniereSauvegardeSessions = 0;
  const session = (jeton) => {
    if (!jeton) return false;
    const h = sha(jeton);
    const s = sessions[h];
    if (!s) return false;
    const t = Date.now();
    if (t - s.vu > INACTIVITE || t - s.cree > DUREE_MAX) {
      delete sessions[h];
      sauverSessions();
      return false;
    }
    s.vu = t;
    if (t - derniereSauvegardeSessions > 60000) {
      derniereSauvegardeSessions = t;
      for (const [k, v] of Object.entries(sessions)) if (t - v.vu > INACTIVITE || t - v.cree > DUREE_MAX) delete sessions[k];
      sauverSessions();
    }
    return true;
  };
  const deconnexion = (jeton) => {
    if (jeton) delete sessions[sha(jeton)];
    sauverSessions();
  };
  const deconnecterTout = () => {
    sessions = {};
    sauverSessions();
  };

  // ---------- Jetons de synchronisation (application Mac) ----------
  const jetons = () => lireJSON("jetons-synchro.json", []);
  const creerJeton = (nom) => {
    const jeton = "lgs_" + crypto.randomBytes(32).toString("base64url");
    const l = jetons();
    l.push({ id: crypto.randomUUID(), nom: String(nom || "Mac").slice(0, 60), hash: sha(jeton), creeLe: new Date().toISOString() });
    ecrireJSON("jetons-synchro.json", l);
    return jeton;
  };
  const listerJetons = () => jetons().map(({ id, nom, creeLe, vuLe }) => ({ id, nom, creeLe, vuLe }));
  const retirerJeton = (id) => ecrireJSON("jetons-synchro.json", jetons().filter((j) => j.id !== id));
  const jetonValide = (jeton) => {
    if (!jeton || !jeton.startsWith("lgs_")) return false;
    const h = Buffer.from(sha(jeton));
    const l = jetons();
    const j = l.find((x) => crypto.timingSafeEqual(Buffer.from(x.hash), h));
    if (!j) return false;
    if (!j.vuLe || Date.now() - Date.parse(j.vuLe) > 3600000) {
      j.vuLe = new Date().toISOString();
      ecrireJSON("jetons-synchro.json", l);
    }
    return true;
  };

  return { nouvelleSession, cles, enregistrerCles, estInstalle, codeInstallation, debutInstallation, finInstallation, connexion, session, deconnexion, deconnecterTout, creerJeton, listerJetons, retirerJeton, jetonValide, lireJSON, ecrireJSON, totp, verifierCode };
}
