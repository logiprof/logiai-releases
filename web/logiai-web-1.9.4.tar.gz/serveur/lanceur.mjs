// Lanceur de Logi AI web : démarre le serveur et le relance après une mise à jour
// (le serveur se termine avec le code 99 une fois les nouveaux fichiers en place).
import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SERVEUR = path.join(path.dirname(fileURLToPath(import.meta.url)), "serveur.mjs");
let enfant;
function demarrer() {
  enfant = spawn(process.execPath, [SERVEUR], { stdio: "inherit", env: { ...process.env, LOGIAI_LANCEUR: "1" } });
  enfant.on("exit", (code, signal) => {
    if (code === 99) {
      console.log("Mise à jour installée : redémarrage de Logi AI web…");
      setTimeout(demarrer, 300);
    } else process.exit(code ?? (signal ? 1 : 0));
  });
}
for (const s of ["SIGTERM", "SIGINT"]) process.on(s, () => (enfant ? enfant.kill(s) : process.exit(0)));
demarrer();
