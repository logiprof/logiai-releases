// Commandes de Logi AI web : mêmes noms et mêmes règles que le cœur Rust de l'application Mac.
// Les clés ne quittent jamais le serveur : l'interface peut les enregistrer ou les tester, pas les relire.
import fs from "node:fs";
import path from "node:path";

const FOURNISSEURS = ["anthropic", "google", "mistral", "openrouter", "openai", "deepseek"];
const RACINE_VIRTUELLE = "/Logi AI";

const attendre = (ms) => new Promise((r) => setTimeout(r, ms));
async function requete(url, options = {}, delai = 600000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), delai);
  try {
    return await fetch(url, { ...options, signal: ctl.signal, headers: { "User-Agent": "LogiAI", ...(options.headers || {}) } });
  } finally {
    clearTimeout(t);
  }
}
void attendre;

export function creerCommandes({ securite, DONNEES }) {
  const FICHIERS = path.join(DONNEES, "fichiers");
  fs.mkdirSync(FICHIERS, { recursive: true });

  const lireCle = (f) => securite.cles()[f];
  const verifierFournisseur = (p) => {
    if (!FOURNISSEURS.includes(p)) throw `Fournisseur inconnu : ${p}`;
  };

  // ---------- Fichiers : « /Logi AI/… » correspond au dossier donnees/fichiers du serveur ----------
  const reel = (chemin) => {
    if (typeof chemin !== "string") throw "Chemin invalide.";
    let c = chemin.replace(/\\/g, "/");
    if (c === RACINE_VIRTUELLE || c.startsWith(RACINE_VIRTUELLE + "/")) c = c.slice(RACINE_VIRTUELLE.length);
    else throw "Chemin non autorisé.";
    const p = path.resolve(FICHIERS, "." + (c || "/"));
    if (p !== FICHIERS && !p.startsWith(FICHIERS + path.sep)) throw "Chemin non autorisé.";
    return p;
  };
  const virtuel = (p) => RACINE_VIRTUELLE + p.slice(FICHIERS.length).split(path.sep).join("/");

  // ---------- IA ----------
  const BASES = { openai: "https://api.openai.com/v1", mistral: "https://api.mistral.ai/v1", deepseek: "https://api.deepseek.com", openrouter: "https://openrouter.ai/api/v1" };
  const NOMS = { openai: "OpenAI", mistral: "Mistral", deepseek: "DeepSeek", openrouter: "OpenRouter", anthropic: "Anthropic", google: "Google Gemini" };
  const erreurHttp = (f, code, corps) => {
    let detail = String(corps).slice(0, 300);
    try {
      const v = JSON.parse(corps);
      detail = v?.error?.message ?? v?.message ?? (typeof v?.error === "string" ? v.error : detail);
    } catch {
      /* corps non JSON */
    }
    const debut =
      code === 401 || code === 403
        ? "Clé refusée par le fournisseur"
        : code === 402
          ? "Crédit insuffisant chez le fournisseur"
          : code === 404
            ? "Modèle introuvable (vérifiez le modèle choisi dans les Réglages)"
            : code === 429
              ? "Quota atteint chez le fournisseur (limite gratuite ou trop de demandes)"
              : code >= 500
                ? "Le fournisseur est momentanément indisponible"
                : "Le fournisseur a refusé la demande";
    return `${debut} (${f}, code ${code}). ${detail}`;
  };
  const envoyer = async (url, options, f) => {
    let r;
    try {
      r = await requete(url, options);
    } catch (e) {
      throw `Connexion impossible à ${f}. (${e?.message ?? e})`;
    }
    const corps = await r.text();
    if (!r.ok) throw erreurHttp(f, r.status, corps);
    try {
      return JSON.parse(corps);
    } catch (e) {
      throw `Réponse illisible de ${f} : ${e.message}`;
    }
  };
  const json = (corps) => ({ "Content-Type": "application/json", ...corps });

  async function generer(d) {
    verifierFournisseur(d.fournisseur);
    const cle = lireCle(d.fournisseur);
    if (!cle) throw "Aucune clé API enregistrée pour ce fournisseur (Réglages › Clés API).";
    const max = d.max_tokens ?? 8000;
    if (d.fournisseur === "anthropic") {
      const messages = d.messages.map((m) => ({
        role: m.role,
        content: m.contenu.map((p) => (p.type === "image" ? { type: "image", source: { type: "base64", media_type: p.media, data: p.donnees } } : { type: "text", text: p.texte ?? "" })),
      }));
      const v = await envoyer("https://api.anthropic.com/v1/messages", { method: "POST", headers: json({ "x-api-key": cle, "anthropic-version": "2023-06-01" }), body: JSON.stringify({ model: d.modele, max_tokens: max, system: d.systeme, messages }) }, "Anthropic");
      return { texte: (v.content || []).map((b) => b.text || "").join(""), tokens_entree: v.usage?.input_tokens ?? 0, tokens_sortie: v.usage?.output_tokens ?? 0, modele: d.modele };
    }
    if (d.fournisseur === "google") {
      const contents = d.messages.map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: m.contenu.map((p) => (p.type === "image" ? { inlineData: { mimeType: p.media, data: p.donnees } } : { text: p.texte ?? "" })) }));
      const generationConfig = { maxOutputTokens: max, ...(d.json ? { responseMimeType: "application/json" } : {}) };
      const v = await envoyer(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(d.modele)}:generateContent`, { method: "POST", headers: json({ "x-goog-api-key": cle }), body: JSON.stringify({ systemInstruction: { parts: [{ text: d.systeme }] }, contents, generationConfig }) }, "Google Gemini");
      const texte = (v.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
      if (!texte) throw `Gemini n'a renvoyé aucun texte (raison : ${v.candidates?.[0]?.finishReason ?? v.promptFeedback?.blockReason ?? "inconnue"}).`;
      return { texte, tokens_entree: v.usageMetadata?.promptTokenCount ?? 0, tokens_sortie: v.usageMetadata?.candidatesTokenCount ?? 0, modele: d.modele };
    }
    const f = d.fournisseur;
    const messages = [{ role: "system", content: d.systeme }];
    for (const m of d.messages) {
      const parts = m.contenu.map((p) => (p.type === "image" ? { type: "image_url", image_url: { url: `data:${p.media ?? ""};base64,${p.donnees ?? ""}` } } : { type: "text", text: p.texte ?? "" }));
      messages.push({ role: m.role, content: parts.length === 1 && parts[0].type === "text" ? parts[0].text : parts });
    }
    const body = { model: d.modele, messages };
    if (f === "openai") body.max_completion_tokens = max;
    else body.max_tokens = max;
    if (d.json && f !== "openrouter") body.response_format = { type: "json_object" };
    const v = await envoyer(`${BASES[f]}/chat/completions`, { method: "POST", headers: json({ Authorization: `Bearer ${cle}` }), body: JSON.stringify(body) }, NOMS[f]);
    const texte = v.choices?.[0]?.message?.content ?? "";
    if (!texte) throw `${NOMS[f]} n'a renvoyé aucun texte.`;
    return { texte, tokens_entree: v.usage?.prompt_tokens ?? 0, tokens_sortie: v.usage?.completion_tokens ?? 0, modele: v.model ?? d.modele };
  }

  async function modeles(f) {
    verifierFournisseur(f);
    const cle = lireCle(f);
    if (!cle) throw "Aucune clé enregistrée pour ce fournisseur.";
    let url, headers;
    if (f === "anthropic") [url, headers] = ["https://api.anthropic.com/v1/models?limit=100", { "x-api-key": cle, "anthropic-version": "2023-06-01" }];
    else if (f === "google") [url, headers] = ["https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { "x-goog-api-key": cle }];
    else if (f === "openrouter") [url, headers] = ["https://openrouter.ai/api/v1/models", {}];
    else [url, headers] = [`${BASES[f]}/models`, { Authorization: `Bearer ${cle}` }];
    const v = await envoyer(url, { headers }, f);
    let ids = f === "google" ? (v.models || []).filter((m) => (m.supportedGenerationMethods || []).includes("generateContent")).map((m) => m.name.replace(/^models\//, "")) : (v.data || []).map((m) => m.id).filter(Boolean);
    if (f === "openrouter") ids = ids.filter((id) => id.endsWith(":free") || id === "openrouter/free");
    return ids;
  }

  async function genererImage({ modele, consigne, references = [], format }) {
    const cle = lireCle("google");
    if (!cle) throw "Ajoutez d'abord une clé Gemini (Réglages › Clés API) : les illustrations utilisent Gemini.";
    const parts = [{ text: consigne }, ...references.map((r) => ({ inline_data: { mime_type: r.mime, data: r.donnees } }))];
    const v = await envoyer(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(modele)}:generateContent`, { method: "POST", headers: json({ "x-goog-api-key": cle }), body: JSON.stringify({ contents: [{ role: "user", parts }], generationConfig: { responseModalities: ["IMAGE", "TEXT"], imageConfig: { aspectRatio: format } } }) }, "Google Gemini");
    let texte = "";
    for (const p of v.candidates?.[0]?.content?.parts || []) {
      if (p.text) texte += p.text;
      const d = p.inlineData || p.inline_data;
      if (d?.data) return { mime: d.mimeType || d.mime_type || "image/png", donnees: d.data, texte, tokens_entree: v.usageMetadata?.promptTokenCount ?? 0, tokens_sortie: v.usageMetadata?.candidatesTokenCount ?? 0 };
    }
    const raison = v.candidates?.[0]?.finishReason ?? v.promptFeedback?.blockReason ?? "";
    if (["SAFETY", "IMAGE_SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST"].includes(raison)) throw "Gemini a refusé cette image (règles de sécurité). Reformulez la demande.";
    throw texte ? `Gemini n'a pas produit d'image : ${texte}` : `Gemini n'a pas produit d'image${raison ? ` (${raison})` : ""}.`;
  }

  // ---------- Clés API ----------
  const nettoyer = (k) => String(k || "").replace(/[^\x21-\x7e]/g, "");
  function formeCle(p, k) {
    if (k.includes("…") || k.includes("...") || k.includes("*")) throw "Cette clé semble raccourcie (« … » ou « * »). Copiez la clé complète au moment de sa création.";
    const [prefixe, min] = { anthropic: ["sk-ant-", 60], openai: ["sk-", 40], openrouter: ["sk-or-", 40], deepseek: ["sk-", 30] }[p] ?? [null, 20];
    if (prefixe && !k.startsWith(prefixe)) throw `Une clé de ce fournisseur commence par « ${prefixe} ». Vérifiez que vous avez collé la bonne clé.`;
    if (k.length < min) throw `Cette clé ne compte que ${k.length} caractères : elle semble incomplète. Copiez-la en entier au moment de sa création.`;
  }
  async function testerCle(p) {
    verifierFournisseur(p);
    const k = lireCle(p);
    if (!k) throw "Aucune clé enregistrée pour ce fournisseur.";
    const cfg = {
      anthropic: ["https://api.anthropic.com/v1/models", { "x-api-key": k, "anthropic-version": "2023-06-01" }],
      google: ["https://generativelanguage.googleapis.com/v1beta/models", { "x-goog-api-key": k }],
      mistral: ["https://api.mistral.ai/v1/models", { Authorization: `Bearer ${k}` }],
      openrouter: ["https://openrouter.ai/api/v1/key", { Authorization: `Bearer ${k}` }],
      openai: ["https://api.openai.com/v1/models", { Authorization: `Bearer ${k}` }],
      deepseek: ["https://api.deepseek.com/models", { Authorization: `Bearer ${k}` }],
    }[p];
    let r;
    try {
      r = await requete(cfg[0], { headers: cfg[1] }, 20000);
    } catch (e) {
      throw `Connexion impossible. (${e?.message ?? e})`;
    }
    if (r.status === 401 || r.status === 403) throw `Clé refusée par le fournisseur (code ${r.status}). Elle est peut-être incomplète, désactivée ou supprimée : créez une nouvelle clé et copiez-la en entier dès sa création.`;
    if (!r.ok) throw `Le fournisseur a répondu avec une erreur (code ${r.status}).`;
    const v = await r.json().catch(() => null);
    const n = (v?.data || v?.models)?.length;
    return n ? `Clé valide · ${n} modèles disponibles` : "Clé valide";
  }

  async function solde(f) {
    const k = lireCle(f);
    if (!k) throw "Aucune clé pour ce fournisseur.";
    const lire = async (url) => {
      const r = await requete(url, { headers: { Authorization: `Bearer ${k}` } }, 20000);
      if (!r.ok) throw `Solde non lisible (code ${r.status}).`;
      return r.json();
    };
    const nb = (v) => (v === null || v === undefined || v === "" ? null : Number(v));
    if (f === "deepseek") {
      const v = await lire("https://api.deepseek.com/user/balance");
      const l = v.balance_infos || [];
      const i = l.find((x) => x.currency === "USD") || l[0] || {};
      return { montant: nb(i.total_balance), devise: i.currency || "USD", detail: `dont offert : ${i.granted_balance ?? "0"} · rechargé : ${i.topped_up_balance ?? "0"}` };
    }
    if (f === "openrouter") {
      try {
        const v = await lire("https://openrouter.ai/api/v1/credits");
        const total = nb(v.data?.total_credits) ?? 0;
        const utilise = nb(v.data?.total_usage) ?? 0;
        return { montant: total - utilise, devise: "USD", detail: `acheté : ${total.toFixed(2)} $ · utilisé : ${utilise.toFixed(2)} $` };
      } catch {
        const d = (await lire("https://openrouter.ai/api/v1/key")).data || {};
        const utilise = nb(d.usage) ?? 0;
        return { montant: nb(d.limit_remaining), devise: "USD", detail: d.limit_remaining == null ? `utilisé avec cette clé : ${utilise.toFixed(2)} $ (le solde total n'est lisible qu'avec une clé de gestion)` : `restant sur la limite de cette clé · utilisé : ${utilise.toFixed(2)} $` };
      }
    }
    if (f === "mistral") {
      const v = await lire("https://api.mistral.ai/v1/billing/subscription").catch(() => null);
      const m = nb(v?.credit_balance);
      if (m === null) throw "Mistral ne donne pas le solde avec cette clé.";
      return { montant: m, devise: "EUR", detail: "crédits restants" };
    }
    throw "Ce fournisseur ne permet pas de lire le solde avec une clé API.";
  }

  // ---------- WordPress ----------
  const sitesWP = () => {
    const m = securite.cles();
    try {
      if (m["wordpress-sites"]) return JSON.parse(m["wordpress-sites"]);
    } catch {
      /* format illisible */
    }
    if (m.wordpress) {
      try {
        const a = JSON.parse(m.wordpress);
        return [{ id: "principal", nom: a.site.replace(/^https:\/\//, ""), site: a.site, utilisateur: a.utilisateur, mot_de_passe: a.mot_de_passe }];
      } catch {
        /* rien */
      }
    }
    return [];
  };
  const enregistrerSites = (l) => {
    const m = securite.cles();
    m["wordpress-sites"] = JSON.stringify(l);
    delete m.wordpress;
    securite.enregistrerCles(m);
  };
  const trouverSite = (id) => {
    const l = sitesWP();
    const s = id ? l.find((x) => x.id === id) : l[0];
    if (!s) throw id ? "Ce site n'est plus enregistré dans Logi AI." : "Aucun site WordPress relié (espace Sites internet).";
    return s;
  };
  const auth = (s) => "Basic " + Buffer.from(`${s.utilisateur}:${s.mot_de_passe}`).toString("base64");
  async function reponseWP(r) {
    const total = r.headers.get("x-wp-total");
    const pages = r.headers.get("x-wp-totalpages");
    const corps = await r.json().catch(() => null);
    if (r.status === 401) throw "Le site refuse l'accès : vérifiez l'identifiant et le mot de passe d'application.";
    if (!r.ok) {
      const msg = corps?.message ?? "";
      throw r.status === 403 ? `Le site refuse cette action (droits insuffisants pour ce compte). ${msg}` : r.status === 404 ? `Introuvable sur le site. ${msg}` : `Le site a répondu avec une erreur (code ${r.status}). ${msg}`;
    }
    return { donnees: corps, pages: pages ? Number(pages) : null, total: total ? Number(total) : null };
  }
  const cheminSur = (c) => typeof c === "string" && !c.includes("..") && !c.toLowerCase().includes("_method") && !c.includes("://");
  const INTERDITS = ["wp/v2/users", "wp/v2/settings", "wp/v2/themes", "wp/v2/comments", "wp/v2/menu", "wp/v2/navigation", "wp/v2/global-styles", "wp/v2/template", "wp/v2/widget", "wp/v2/sidebars", "wp/v2/application-passwords"];
  const ecriturePermise = (c) => {
    const base = c.split("?")[0];
    return cheminSur(c) && (base.startsWith("wp/v2/") || base.startsWith("logiai/v1/") || base.startsWith("sensei-internal/v1/course-structure/")) && !INTERDITS.some((i) => base.startsWith(i));
  };
  const appelWP = async (url, options) => {
    try {
      return await requete(url, options, 180000);
    } catch (e) {
      throw `Connexion au site impossible : ${e?.message ?? e}`;
    }
  };
  const MIMES = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif", svg: "image/svg+xml", pdf: "application/pdf", mp4: "video/mp4", mp3: "audio/mpeg", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };

  // ---------- GitHub ----------
  const accesGH = () => {
    const j = securite.cles().github;
    if (!j) throw "GitHub n'est pas encore relié (Réglages › GitHub).";
    return JSON.parse(j);
  };
  const messageGH = (code, corps) => {
    const d = corps?.message ?? "";
    if (code === 401) return "GitHub refuse le jeton : il est peut-être expiré ou supprimé. Créez-en un nouveau (Réglages › GitHub).";
    if (code === 403) return `GitHub refuse cette action : le jeton n'a pas toutes les autorisations nécessaires (Administration et Contents en lecture et écriture). ${d}`;
    if (code === 404) return "Dépôt ou fichier introuvable sur GitHub (ou jeton sans accès à ce dépôt).";
    if (code === 422) return `GitHub refuse la demande : ${d}`;
    return `GitHub a répondu avec une erreur (code ${code}). ${d}`;
  };
  const cheminGH = (c, login) => typeof c === "string" && !c.includes("..") && (c.startsWith("/user/repos") || c === "/user" || c.startsWith(`/repos/${login}/`));

  // ---------- Bibliothèque ----------
  const EXT_BIB = new Set(["png", "jpg", "jpeg", "webp", "gif", "svg", "heic", "avif", "mp4", "mov", "webm", "m4v", "lottie", "html", "htm", "zip", "pdf", "docx", "xlsx", "pptx", "md", "csv", "txt", "mp3", "wav", "m4a"]);
  const IGNORES = new Set(["supports", "node_modules", "plugin-update-checker", "vendor", "__MACOSX"]);
  function parcourir(dossier, prof, sortie) {
    if (prof > 7 || sortie.length >= 4000) return;
    let entrees = [];
    try {
      entrees = fs.readdirSync(dossier, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entrees) {
      if (e.name.startsWith(".") || IGNORES.has(e.name)) continue;
      const p = path.join(dossier, e.name);
      if (e.isDirectory()) {
        parcourir(p, prof + 1, sortie);
        continue;
      }
      const ext = path.extname(e.name).slice(1).toLowerCase();
      if (!EXT_BIB.has(ext) || e.name === "CONSIGNES.md") continue;
      const st = fs.statSync(p);
      sortie.push({ chemin: virtuel(p), nom: e.name, dossier: path.relative(FICHIERS, path.dirname(p)).split(path.sep).join("/"), ext, taille: st.size, modifie: Math.round(st.mtimeMs) });
      if (sortie.length >= 4000) return;
    }
  }

  const surMac = () => {
    throw "Disponible uniquement dans l'application Mac (les agents de code et le Finder ne fonctionnent pas en ligne).";
  };

  const commandes = {
    // Clés
    api_key_status: () => Object.fromEntries(FOURNISSEURS.map((p) => [p, !!lireCle(p)])),
    api_key_hints: () => Object.fromEntries(FOURNISSEURS.filter((p) => lireCle(p)).map((p) => [p, ((k) => (k.length > 12 ? `${k.slice(0, 7)}…${k.slice(-4)} · ${k.length} caractères` : `${k.length} caractères`))(lireCle(p))])),
    save_api_key: ({ provider, key }) => {
      verifierFournisseur(provider);
      const k = nettoyer(key);
      formeCle(provider, k);
      securite.enregistrerCles({ ...securite.cles(), [provider]: k });
      return null;
    },
    delete_api_key: ({ provider }) => {
      verifierFournisseur(provider);
      const m = securite.cles();
      delete m[provider];
      securite.enregistrerCles(m);
      return null;
    },
    test_api_key: ({ provider }) => testerCle(provider),
    generer_texte: ({ demande }) => generer(demande),
    generer_image: (a) => genererImage(a),
    lister_modeles: ({ provider }) => modeles(provider),
    solde_ia: ({ fournisseur }) => solde(fournisseur),

    // WordPress
    wp_sites: () => sitesWP().map(({ id, nom, site, utilisateur }) => ({ id, nom, site, utilisateur })),
    wp_ajouter: async ({ id, nom, site, utilisateur, motDePasse }) => {
      site = String(site || "").trim().replace(/\/+$/, "");
      if (!site.startsWith("https://") || site.includes(" ")) throw "L'adresse du site doit commencer par https://";
      const mdp = String(motDePasse || "").replace(/\s/g, "");
      if (mdp.length !== 24) throw "Un mot de passe d'application WordPress compte 24 caractères (espaces non compris).";
      utilisateur = String(utilisateur || "").trim();
      const s0 = { site, utilisateur, mot_de_passe: mdp };
      const r = await reponseWP(await appelWP(`${site}/wp-json/wp/v2/users/me?context=edit`, { headers: { Authorization: auth(s0) } }));
      const l = sitesWP();
      const ident = id || `site-${Date.now()}`;
      const n = { id: ident, nom: String(nom || "").trim() || site.replace(/^https:\/\//, ""), site, utilisateur, mot_de_passe: mdp };
      const i = l.findIndex((x) => x.id === ident);
      if (i >= 0) l[i] = n;
      else l.push(n);
      enregistrerSites(l);
      return r.donnees?.name ?? "utilisateur";
    },
    wp_retirer: ({ id }) => {
      enregistrerSites(sitesWP().filter((s) => s.id !== id));
      return null;
    },
    wp_lire: async ({ chemin, site }) => {
      if (!cheminSur(chemin)) throw "Chemin non autorisé.";
      const s = trouverSite(site);
      return reponseWP(await appelWP(`${s.site}/wp-json/${chemin}`, { headers: { Authorization: auth(s) } }));
    },
    wp_ecrire: async ({ site, chemin, corps }) => {
      if (!ecriturePermise(chemin)) throw "Action non autorisée depuis Logi AI.";
      const s = trouverSite(site);
      return reponseWP(await appelWP(`${s.site}/wp-json/${chemin}`, { method: "POST", headers: { Authorization: auth(s), "Content-Type": "application/json" }, body: JSON.stringify(corps) }));
    },
    wp_televerser: async ({ site, chemin }) => {
      const p = reel(chemin);
      const nom = path.basename(p);
      const ext = path.extname(nom).slice(1).toLowerCase();
      const mime = MIMES[ext];
      if (!mime) throw "Type de fichier non pris en charge par la médiathèque (images, PDF, vidéos MP4, sons MP3, Word, Excel).";
      const s = trouverSite(site);
      const nomAscii = nom.replace(/[^A-Za-z0-9._-]/g, "-");
      return reponseWP(await appelWP(`${s.site}/wp-json/wp/v2/media`, { method: "POST", headers: { Authorization: auth(s), "Content-Type": mime, "Content-Disposition": `attachment; filename="${nomAscii}"` }, body: fs.readFileSync(p) }));
    },

    // GitHub
    gh_enregistrer: async ({ jeton }) => {
      jeton = nettoyer(jeton);
      if (!(jeton.startsWith("github_pat_") || jeton.startsWith("ghp_")) || jeton.length < 30) throw "Un jeton GitHub commence par « github_pat_ » (ou « ghp_ »). Copiez-le en entier au moment de sa création.";
      const r = await requete("https://api.github.com/user", { headers: { Authorization: `Bearer ${jeton}` } }, 120000).catch((e) => {
        throw `Connexion à GitHub impossible : ${e?.message ?? e}`;
      });
      const corps = await r.json().catch(() => ({}));
      if (!r.ok) throw messageGH(r.status, corps);
      securite.enregistrerCles({ ...securite.cles(), github: JSON.stringify({ jeton, login: corps.login ?? "" }) });
      return corps.login ?? "";
    },
    gh_supprimer: () => {
      const m = securite.cles();
      delete m.github;
      securite.enregistrerCles(m);
      return null;
    },
    gh_etat: () => {
      try {
        return accesGH().login;
      } catch {
        return null;
      }
    },
    gh_requete: async ({ methode, chemin, corps }) => {
      const a = accesGH();
      if (!cheminGH(chemin, a.login)) throw "Chemin GitHub non autorisé.";
      if (!["GET", "POST", "PATCH", "PUT"].includes(methode)) throw "Méthode non autorisée.";
      const r = await requete(`https://api.github.com${chemin}`, { method: methode, headers: { Authorization: `Bearer ${a.jeton}`, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", ...(corps ? { "Content-Type": "application/json" } : {}) }, body: corps ? JSON.stringify(corps) : undefined }, 120000).catch((e) => {
        throw `Connexion à GitHub impossible : ${e?.message ?? e}`;
      });
      const v = await r.json().catch(() => null);
      if (!r.ok) throw messageGH(r.status, v);
      return v;
    },
    gh_archive: async ({ depot, branche }) => {
      const a = accesGH();
      const chemin = `/repos/${a.login}/${depot}/zipball/${branche}`;
      if (String(depot).includes("/") || String(branche).includes("..") || !cheminGH(chemin, a.login)) throw "Dépôt non autorisé.";
      const r = await requete(`https://api.github.com${chemin}`, { headers: { Authorization: `Bearer ${a.jeton}` } }, 120000).catch((e) => {
        throw `Téléchargement impossible : ${e?.message ?? e}`;
      });
      if (!r.ok) throw messageGH(r.status, null);
      return Buffer.from(await r.arrayBuffer()).toString("base64");
    },

    // Fichiers (espace « /Logi AI » du serveur)
    dossier_par_defaut: () => RACINE_VIRTUELLE,
    creer_dossier: ({ chemin }) => {
      fs.mkdirSync(reel(chemin), { recursive: true });
      return null;
    },
    ecrire_fichier: ({ chemin, donneesBase64 }) => {
      const p = reel(chemin);
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, Buffer.from(donneesBase64, "base64"));
      return null;
    },
    lire_fichier: ({ chemin }) => {
      const p = reel(chemin);
      if (fs.statSync(p).size > 300 * 1024 * 1024) throw "Fichier trop volumineux (plus de 300 Mo).";
      return fs.readFileSync(p).toString("base64");
    },
    bib_lister: () => {
      const l = [];
      parcourir(FICHIERS, 0, l);
      return l.sort((a, b) => b.modifie - a.modifie);
    },
    sauvegarder: ({ dossier, contenu }) => {
      const d = reel(dossier);
      fs.mkdirSync(d, { recursive: true });
      const n = new Date();
      const horo = `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")} ${String(n.getHours()).padStart(2, "0")}h${String(n.getMinutes()).padStart(2, "0")}`;
      const p = path.join(d, `Logi AI sauvegarde ${horo}.json`);
      fs.writeFileSync(p, contenu);
      const anciennes = fs.readdirSync(d).filter((x) => x.startsWith("Logi AI sauvegarde ") && x.endsWith(".json")).sort();
      while (anciennes.length > 30) fs.rmSync(path.join(d, anciennes.shift()));
      return virtuel(p);
    },

    // Propres au Mac
    cc_detecter: () => ({ installe: false, web: true }),
    codex_detecter: () => ({ installe: false, web: true }),
    cc_preparer: surMac,
    cc_lancer: surMac,
    cc_arreter: surMac,
    cc_livrables: () => [],
    ouvrir_chemin: surMac,
  };

  return { commandes, reel, virtuel, FICHIERS, RACINE_VIRTUELLE };
}
