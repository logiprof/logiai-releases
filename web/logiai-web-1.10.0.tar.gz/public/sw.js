// Service worker de Logi AI web : notifications « push » (tâche terminée, etc.).
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("push", (e) => {
  let m = { titre: "Logi AI", corps: "", url: "/" };
  try {
    m = { ...m, ...e.data.json() };
  } catch {
    /* message illisible */
  }
  e.waitUntil(self.registration.showNotification(m.titre, { body: m.corps, icon: "/icone-192.png", badge: "/icone-192.png", data: { url: m.url } }));
});

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = e.notification.data?.url || "/";
  e.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((l) => {
      for (const c of l) if ("focus" in c) return c.focus();
      return self.clients.openWindow(url);
    }),
  );
});
