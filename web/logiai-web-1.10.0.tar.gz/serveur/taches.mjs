// Tâches exécutées par le serveur (chat, productions, illustrations, scénarios) :
// elles continuent même si l'application (web ou Mac) est fermée.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export function creerTaches({ DONNEES, lireDonnees, modifierDonnees, commandes, push }) {
  const fichier = path.join(DONNEES, "taches.json");
  /** @type {Map<string, any>} */
  const taches = new Map();
  // Tâches d'avant un redémarrage : celles qui tournaient sont marquées interrompues.
  try {
    for (const t of JSON.parse(fs.readFileSync(fichier, "utf8"))) {
      if (t.etat === "encours") Object.assign(t, { etat: "erreur", erreur: "Interrompue par un redémarrage du serveur. Relancez-la.", fin: Date.now() });
      taches.set(t.id, t);
    }
  } catch {
    /* première fois */
  }
  const sauver = () => {
    const l = [...taches.values()].sort((a, b) => b.debut - a.debut).slice(0, 50);
    fs.writeFileSync(fichier, JSON.stringify(l.map(({ image, ...t }) => t)), { mode: 0o600 });
  };

  let moteur = null;
  const chargerMoteur = async () => {
    if (!moteur) {
      globalThis.__logiaiCommandes = commandes;
      moteur = await import("./moteur/moteur.mjs");
    }
    return moteur;
  };

  const hote = {
    lire: () => lireDonnees(),
    // Le moteur reçoit des données normalisées (même si le serveur n'en a encore aucune).
    modifier: (f) => modifierDonnees(f(lireDonnees())),
    cles: () => commandes.api_key_status(),
  };

  let scenarioEnCours = false;

  async function executer(t, demande) {
    try {
      const m = await chargerMoteur();
      const r = await m.executerTache(
        demande,
        hote,
        (etape) => {
          t.etape = etape;
          t.maj = Date.now();
        },
        (ex) => {
          if (!ex) return;
          // État du scénario sans les contenus (trop lourds) pour l'affichage.
          t.scenario = { ...ex, etapes: ex.etapes.map(({ contenu, ...e }) => e) };
          t.maj = Date.now();
        },
      );
      Object.assign(t, { etat: "fini", resultat: r, image: r.image, fin: Date.now(), maj: Date.now() });
      delete t.resultat?.image;
      void push.envoyer(`Terminé : ${t.titre}`, r.resume || "Ouvrez Logi AI pour voir le résultat.", "/");
    } catch (e) {
      const message = typeof e === "string" ? e : (e?.message ?? "Erreur inattendue.");
      Object.assign(t, { etat: "erreur", erreur: message, fin: Date.now(), maj: Date.now() });
      if (typeof e !== "string" && !(e?.name === "ErreurIA")) console.error(`[tâche ${t.type}]`, e);
      void push.envoyer(`Échec : ${t.titre}`, message.slice(0, 180), "/");
    } finally {
      if (demande.type === "scenario") scenarioEnCours = false;
      sauver();
    }
  }

  return {
    /** Lance une tâche ; renvoie son identifiant. */
    lancer(titre, demande, origine) {
      if (!demande || !["chat", "production", "illustration", "scenario"].includes(demande.type)) throw new Error("Tâche inconnue.");
      // Discussion déjà en cours de réponse : on ajoute simplement les nouveaux messages.
      if (demande.type === "chat") {
        const id = demande.conversation?.id;
        const enCours = [...taches.values()].find((x) => x.etat === "encours" && x.type === "chat" && x.conversationId === id);
        if (enCours) {
          hote.modifier((d) => {
            const c = d.conversations.find((x) => x.id === id);
            if (!c) return d;
            const connus = new Set(c.messages.map((m) => m.role + m.date));
            const nouveaux = demande.conversation.messages.filter((m) => !connus.has(m.role + m.date));
            return nouveaux.length ? { ...d, conversations: d.conversations.map((x) => (x.id === id ? { ...c, messages: [...c.messages, ...nouveaux] } : x)) } : d;
          });
          return enCours.id;
        }
      }
      if (demande.type === "scenario") {
        if (scenarioEnCours) throw new Error("Un scénario est déjà en cours sur le serveur.");
        scenarioEnCours = true;
      }
      const t = { id: crypto.randomUUID(), type: demande.type, titre: String(titre || "Tâche").slice(0, 160), etat: "encours", etape: "En attente…", debut: Date.now(), maj: Date.now(), origine, conversationId: demande.type === "chat" ? demande.conversation?.id : undefined };
      taches.set(t.id, t);
      sauver();
      void executer(t, demande);
      return t.id;
    },
    /** Tâches récentes (sans les images). */
    lister() {
      return [...taches.values()]
        .sort((a, b) => b.debut - a.debut)
        .slice(0, 30)
        .map(({ image, ...t }) => t);
    },
    lire(id) {
      return taches.get(id) ?? null;
    },
    async arreter(id) {
      const t = taches.get(id);
      if (!t || t.etat !== "encours") return false;
      if (t.type === "scenario") await (await chargerMoteur()).arreterScenario();
      t.etape = "Arrêt demandé…";
      t.maj = Date.now();
      return true;
    },
  };
}
