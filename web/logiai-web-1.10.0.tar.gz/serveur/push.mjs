// Notifications « push » (Web Push, RFC 8291 + VAPID RFC 8292), sans dépendance externe.
// Sur iPhone : fonctionne quand Logi AI web est ajouté à l'écran d'accueil (iOS 16.4+).
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const b64u = (b) => Buffer.from(b).toString("base64url");
const deB64u = (s) => Buffer.from(String(s), "base64url");

export function creerPush(DONNEES) {
  const fCles = path.join(DONNEES, "vapid.json");
  const fAbos = path.join(DONNEES, "push.json");
  let vapid;
  try {
    vapid = JSON.parse(fs.readFileSync(fCles, "utf8"));
  } catch {
    const ec = crypto.createECDH("prime256v1");
    ec.generateKeys();
    vapid = { publique: b64u(ec.getPublicKey()), privee: b64u(ec.getPrivateKey()) };
    fs.writeFileSync(fCles, JSON.stringify(vapid), { mode: 0o600 });
  }
  const pub = deB64u(vapid.publique);
  const clePrivee = crypto.createPrivateKey({ key: { kty: "EC", crv: "P-256", d: vapid.privee, x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) }, format: "jwk" });

  const lireAbos = () => {
    try {
      return JSON.parse(fs.readFileSync(fAbos, "utf8"));
    } catch {
      return [];
    }
  };
  const ecrireAbos = (l) => fs.writeFileSync(fAbos, JSON.stringify(l), { mode: 0o600 });

  function jwt(audience) {
    const entete = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" }));
    const corps = b64u(JSON.stringify({ aud: audience, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: "mailto:notifications@logiprof.ch" }));
    const sig = crypto.sign("sha256", Buffer.from(`${entete}.${corps}`), { key: clePrivee, dsaEncoding: "ieee-p1363" });
    return `${entete}.${corps}.${b64u(sig)}`;
  }

  /** Chiffrement aes128gcm du message pour un abonnement (RFC 8291). */
  function chiffrer(abo, texte) {
    const uaPublic = deB64u(abo.keys.p256dh);
    const auth = deB64u(abo.keys.auth);
    const eph = crypto.createECDH("prime256v1");
    eph.generateKeys();
    const asPublic = eph.getPublicKey();
    const secret = eph.computeSecret(uaPublic);
    const ikm = Buffer.from(crypto.hkdfSync("sha256", secret, auth, Buffer.concat([Buffer.from("WebPush: info\0"), uaPublic, asPublic]), 32));
    const sel = crypto.randomBytes(16);
    const cek = Buffer.from(crypto.hkdfSync("sha256", ikm, sel, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
    const nonce = Buffer.from(crypto.hkdfSync("sha256", ikm, sel, Buffer.from("Content-Encoding: nonce\0"), 12));
    const c = crypto.createCipheriv("aes-128-gcm", cek, nonce);
    const chiffre = Buffer.concat([c.update(Buffer.concat([Buffer.from(texte, "utf8"), Buffer.from([2])])), c.final(), c.getAuthTag()]);
    const rs = Buffer.alloc(4);
    rs.writeUInt32BE(4096);
    return Buffer.concat([sel, rs, Buffer.from([asPublic.length]), asPublic, chiffre]);
  }

  async function envoyerA(abo, message) {
    const url = new URL(abo.endpoint);
    const r = await fetch(abo.endpoint, {
      method: "POST",
      headers: { Authorization: `vapid t=${jwt(url.origin)}, k=${vapid.publique}`, "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", TTL: "86400", Urgency: "normal" },
      body: chiffrer(abo, JSON.stringify(message)),
    });
    return r.status;
  }

  return {
    clePublique: () => vapid.publique,
    abonner(abo, appareil) {
      if (!abo?.endpoint?.startsWith("https://") || !abo.keys?.p256dh || !abo.keys?.auth) throw new Error("Abonnement invalide.");
      const l = lireAbos().filter((a) => a.endpoint !== abo.endpoint);
      l.push({ endpoint: abo.endpoint, keys: { p256dh: abo.keys.p256dh, auth: abo.keys.auth }, appareil: String(appareil || "").slice(0, 80), creeLe: new Date().toISOString() });
      ecrireAbos(l);
    },
    desabonner(endpoint) {
      ecrireAbos(lireAbos().filter((a) => a.endpoint !== endpoint));
    },
    nombre: () => lireAbos().length,
    /** Envoie à tous les appareils abonnés ; retire ceux qui n'existent plus. */
    async envoyer(titre, corps, url = "/") {
      const l = lireAbos();
      const morts = [];
      await Promise.all(
        l.map(async (a) => {
          try {
            const s = await envoyerA(a, { titre, corps, url });
            if (s === 404 || s === 410) morts.push(a.endpoint);
          } catch (e) {
            console.error("Notification non envoyée :", e?.message ?? e);
          }
        }),
      );
      if (morts.length) ecrireAbos(lireAbos().filter((a) => !morts.includes(a.endpoint)));
      return l.length - morts.length;
    },
    _chiffrer: chiffrer,
  };
}
